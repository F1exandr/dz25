#Импортируем все необходимые библиотеки
import sqlalchemy.exc
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import psycopg2

# Создание приложения
app = Flask(__name__)

# Конфигурация подключения к базе данных PostgreSQL
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost:5433/contacts'
# Отключение отслеживания изменений в базе данных
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Создание объекта SQLAlchemy для работы с базой данных
db = SQLAlchemy(app)


# Определение модели Contact для таблицы contacts
class Contact(db.Model):
    # Имя таблицы в базе данных
    __tablename__ = 'contacts'

    # Поле id - первичный ключ, целое число
    id = db.Column(db.Integer, primary_key=True)

    # Поле name - строка длиной до 80 символов, не может быть пустым
    name = db.Column(db.String(80), nullable=False)

    # Поле email - строка длиной до 120 символов, не может быть пустым, уникальное
    email = db.Column(db.String(120), nullable=False, unique=True)

    # Метод для представления объекта Contact в виде строки
    def __repr__(self):
        return f'<Contact {self.name}>'


# Создание таблицы contacts в базе данных
with app.app_context():
    db.create_all()


# Маршрут для главной страницы
@app.route('/')
def index():
    # Рендеринг шаблона index.html
    return render_template('index.html')


# Маршрут для страницы контактов
@app.route('/contacts')
def contacts():
    # Получение всех контактов из базы данных
    contacts = Contact.query.all()
    # Рендеринг шаблона contacts.html с передачей контактов
    return render_template('contacts.html', contacts=contacts)


# Маршрут для добавления нового контакта
@app.route('/add_contact', methods=['POST'])
def add_contact():
    # Получение имени и email из формы
    name = request.form['name']
    email = request.form['email']

    # Проверка наличия имени и email
    if not name or not email:
        # Рендеринг шаблона index.html с сообщением об ошибке
        return render_template('index.html', message='Все поля должны быть заполнены')

    # Создание нового контакта
    new_contact = Contact(name=name, email=email)

    # Добавление контакта в базу данных
    db.session.add(new_contact)

    try:
        # Сохранение изменений в базе данных
        db.session.commit()
    except sqlalchemy.exc.IntegrityError:
        # Откат изменений в случае ошибки уникальности email
        db.session.rollback()
        # Рендеринг шаблона index.html с сообщением об ошибке
        return render_template('index.html', message='Этот email уже используется')

    # Перенаправление на страницу контактов
    return redirect(url_for('contacts'))


# Маршрут для удаления контакта
@app.route('/delete/<int:contact_id>')
def delete(contact_id):
    # Получение контакта по id
    contact = Contact.query.get_or_404(contact_id)

    # Удаление контакта из базы данных
    db.session.delete(contact)
    db.session.commit()

    # Перенаправление на страницу контактов
    return redirect(url_for('contacts'))


# Запуск приложения
if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
